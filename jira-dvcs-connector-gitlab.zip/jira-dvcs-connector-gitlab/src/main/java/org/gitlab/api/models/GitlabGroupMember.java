package org.gitlab.api.models;

public class GitlabGroupMember extends GitlabAbstractMember {
}
