package org.gitlab.api.models;

public class GitlabProjectMember extends GitlabAbstractMember {
}
